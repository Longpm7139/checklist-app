'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Filter, Download, Calendar } from 'lucide-react';
import clsx from 'clsx';

interface LogEntry {
    id: string;
    timestamp: string; // formatted string
    inspectorName: string;
    inspectorCode: string;
    systemId: string;
    systemName: string;
    result: 'OK' | 'NOK';
    note: string;
}

export default function ReportsPage() {
    const router = useRouter();
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);

    // Filters
    const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0]); // Default Today YYYY-MM-DD
    const [inspectorFilter, setInspectorFilter] = useState('');
    const [uniqueInspectorNames, setUniqueInspectorNames] = useState<string[]>([]);

    useEffect(() => {
        // Load logs
        const storedLogs = JSON.parse(localStorage.getItem('checklist_logs') || '[]');
        // Logs are stored as they are added, so likely in chronological order. Reverse to see newest first.
        const reversed = storedLogs.reverse();
        setLogs(reversed);

        // Extract unique inspectors for filter info
        const names = Array.from(new Set(reversed.map((l: LogEntry) => l.inspectorName))).filter(Boolean) as string[];
        setUniqueInspectorNames(names);
    }, []);

    useEffect(() => {
        // Filtering Logic
        let result = logs;

        if (dateFilter) {
            // Log timestamp format: "HH:mm dd/MM/yyyy"
            // Filter format: "yyyy-MM-dd"
            // Need to parse log timestamp to compare dates.
            const [filterYear, filterMonth, filterDay] = dateFilter.split('-');

            result = result.filter(log => {
                const parts = log.timestamp.split(' '); // ["HH:mm", "dd/MM/yyyy"]
                if (parts.length < 2) return false;
                const datePart = parts[1]; // "dd/MM/yyyy"
                const [d, m, y] = datePart.split('/');

                return d === filterDay && m === filterMonth && y === filterYear;
            });
        }

        if (inspectorFilter) {
            result = result.filter(log => log.inspectorName === inspectorFilter);
        }

        setFilteredLogs(result);
    }, [logs, dateFilter, inspectorFilter]);

    const handleExport = () => {
        const header = ["Thời gian", "Người thực hiện", "Hệ thống", "Kết quả", "Ghi chú"];
        const rows = filteredLogs.map(l => [
            `"${l.timestamp}"`,
            `"${l.inspectorName}"`,
            `"${l.systemName}"`,
            `"${l.result}"`,
            `"${l.note}"`
        ]);

        const csv = "\uFEFF" + [header.join(','), ...rows.map(r => r.join(','))].join('\n');
        const link = document.createElement('a');
        link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
        link.download = `baocao_hoatdong_${dateFilter}.csv`;
        link.click();
    };

    return (
        <div className="min-h-screen bg-slate-50 p-4 font-sans text-slate-900">
            <div className="max-w-6xl mx-auto">
                <header className="mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="flex items-center gap-4">
                        <button onClick={() => router.push('/')} className="p-2 bg-white rounded-full border border-slate-200 hover:bg-slate-100">
                            <ArrowLeft size={20} className="text-slate-600" />
                        </button>
                        <h1 className="text-2xl font-bold uppercase text-slate-800">Nhật Ký Hoạt Động</h1>
                    </div>
                </header>

                {/* Filters */}
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex flex-col md:flex-row gap-4 items-end">
                    <div className="w-full md:w-auto">
                        <label className="block text-sm font-semibold text-slate-700 mb-1">Chọn Ngày</label>
                        <input
                            type="date"
                            value={dateFilter}
                            onChange={(e) => setDateFilter(e.target.value)}
                            className="bg-slate-50 border border-slate-300 rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div className="w-full md:w-auto">
                        <label className="block text-sm font-semibold text-slate-700 mb-1">Nhân viên</label>
                        <select
                            value={inspectorFilter}
                            onChange={(e) => setInspectorFilter(e.target.value)}
                            className="bg-slate-50 border border-slate-300 rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 w-full md:w-48"
                        >
                            <option value="">Tất cả</option>
                            {uniqueInspectorNames.map(name => (
                                <option key={name} value={name}>{name}</option>
                            ))}
                        </select>
                    </div>

                    <div className="w-full md:w-auto flex-1 flex justify-end">
                        <button
                            onClick={handleExport}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded flex items-center gap-2 shadow transition"
                        >
                            <Download size={18} /> Xuất Excel
                        </button>
                    </div>
                </div>

                {/* Table */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-sm border-b border-slate-200">
                            <tr>
                                <th className="p-4 w-48">Thời gian</th>
                                <th className="p-4 w-48">Người thực hiện</th>
                                <th className="p-4">Hệ thống</th>
                                <th className="p-4 w-32 text-center">Kết quả</th>
                                <th className="p-4">Ghi chú</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredLogs.length > 0 ? (
                                filteredLogs.map(log => (
                                    <tr key={log.id} className="hover:bg-slate-50">
                                        <td className="p-4 font-mono text-sm text-slate-600">{log.timestamp}</td>
                                        <td className="p-4 font-bold text-blue-800">{log.inspectorName}</td>
                                        <td className="p-4 font-medium">{log.systemName}</td>
                                        <td className="p-4 text-center">
                                            <span className={clsx(
                                                "px-2 py-1 rounded text-xs font-bold",
                                                log.result === 'OK' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                                            )}>
                                                {log.result}
                                            </span>
                                        </td>
                                        <td className="p-4 text-slate-500 italic text-sm">{log.note}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={5} className="p-8 text-center text-slate-500 italic">
                                        Không có dữ liệu nào cho ngày đã chọn.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
