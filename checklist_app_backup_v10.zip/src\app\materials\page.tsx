'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Package, CheckCircle, Clock } from 'lucide-react';
import { useUser } from '@/providers/UserProvider';
import { ChecklistItem, SystemCheck } from '@/lib/types';

interface MaterialRequest {
    systemId: string;
    systemName: string;
    itemId: string;
    itemContent: string;
    materialName: string;
    requester: string;
    timestamp: string;
}

export default function MaterialsPage() {
    const router = useRouter();
    const { user: currentUser } = useUser();
    const [requests, setRequests] = useState<MaterialRequest[]>([]);

    useEffect(() => {
        // Protect Route
        if (currentUser && currentUser.role !== 'ADMIN') {
            router.push('/');
            return;
        }

        const systems: SystemCheck[] = JSON.parse(localStorage.getItem('checklist_systems') || '[]');
        const allDetails: Record<string, ChecklistItem[]> = JSON.parse(localStorage.getItem('checklist_details') || '{}');

        const newRequests: MaterialRequest[] = [];

        systems.forEach(sys => {
            const items = allDetails[sys.id];
            if (items) {
                items.forEach(item => {
                    if (item.materialRequest) {
                        newRequests.push({
                            systemId: sys.id,
                            systemName: sys.name,
                            itemId: item.id,
                            itemContent: item.content,
                            materialName: item.materialRequest,
                            requester: item.inspectorName || 'Unknown',
                            timestamp: item.timestamp
                        });
                    }
                });
            }
        });

        setRequests(newRequests);
    }, [currentUser, router]);

    const handleApprove = (req: MaterialRequest) => {
        if (!confirm(`Xác nhận đã cấp phát "${req.materialName}"? Mục này sẽ chuyển sang trạng thái "Fixing" để nhân viên sửa chữa.`)) return;

        const allDetails: Record<string, ChecklistItem[]> = JSON.parse(localStorage.getItem('checklist_details') || '{}');

        if (allDetails[req.systemId]) {
            allDetails[req.systemId] = allDetails[req.systemId].map(d => {
                if (d.id === req.itemId) {
                    return {
                        ...d,
                        materialRequest: undefined, // Clear request
                        status: 'NOK', // Still NOK
                        note: `Đã cấp vật tư: ${req.materialName}. Đang sửa chữa.` // Update note
                    };
                }
                return d;
            });
            localStorage.setItem('checklist_details', JSON.stringify(allDetails));

            // Refresh list
            setRequests(prev => prev.filter(r => r.itemId !== req.itemId));
            alert("Đã xác nhận cấp phát!");
        }
    };

    if (currentUser?.role !== 'ADMIN') return null;

    return (
        <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-900">
            <div className="max-w-5xl mx-auto">
                <header className="flex items-center gap-4 mb-8">
                    <button onClick={() => router.push('/')} className="p-2 bg-white rounded-full border border-slate-200 hover:bg-slate-100">
                        <ArrowLeft size={20} className="text-slate-600" />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold uppercase text-slate-800 flex items-center gap-2">
                            <Package className="text-amber-600" />
                            Quản lý Yêu Cầu Vật Tư
                        </h1>
                        <p className="text-slate-500 text-sm">Danh sách vật tư cần cấp phát cho sửa chữa</p>
                    </div>
                </header>

                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-slate-100 text-slate-700 uppercase text-xs font-bold border-b border-slate-200">
                            <tr>
                                <th className="p-4 w-16 text-center">STT</th>
                                <th className="p-4">Vật tư yêu cầu</th>
                                <th className="p-4">Hệ thống / Lỗi</th>
                                <th className="p-4">Người yêu cầu</th>
                                <th className="p-4 text-center">Thời gian</th>
                                <th className="p-4 text-center">Hành động</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {requests.map((req, idx) => (
                                <tr key={`${req.systemId}_${req.itemId}`} className="hover:bg-slate-50">
                                    <td className="p-4 text-center font-bold text-slate-500">{idx + 1}</td>
                                    <td className="p-4 font-bold text-amber-700 text-lg">
                                        {req.materialName}
                                    </td>
                                    <td className="p-4">
                                        <div className="font-semibold text-slate-800">{req.systemName}</div>
                                        <div className="text-sm text-slate-500">{req.itemContent}</div>
                                    </td>
                                    <td className="p-4 font-medium text-blue-600">
                                        {req.requester}
                                    </td>
                                    <td className="p-4 text-center font-mono text-xs text-slate-500">
                                        {req.timestamp}
                                    </td>
                                    <td className="p-4 text-center">
                                        <button
                                            onClick={() => handleApprove(req)}
                                            className="px-3 py-2 bg-green-600 text-white rounded shadow hover:bg-green-700 flex items-center gap-2 text-sm font-bold mx-auto transition"
                                        >
                                            <CheckCircle size={16} /> Cấp phát
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {requests.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="p-12 text-center text-slate-500 italic flex flex-col items-center gap-2">
                                        <Package size={48} className="text-slate-200" />
                                        <span>Hiện không có yêu cầu vật tư nào.</span>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
