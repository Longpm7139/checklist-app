
import Database from 'better-sqlite3';

const db = new Database('checklist.db', { verbose: console.log });
db.pragma('journal_mode = WAL');

// Initialize Schema
const initDb = () => {
  const createUsersTable = `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      role TEXT DEFAULT 'USER',
      password TEXT
    );
  `;
  db.exec(createUsersTable);

  // Migration: Add password column if not exists (for existing databases)
  try {
    const checkColumn = db.prepare("SELECT count(*) as count FROM pragma_table_info('users') WHERE name='password'");
    const result = checkColumn.get() as { count: number };
    if (result.count === 0) {
      db.exec('ALTER TABLE users ADD COLUMN password TEXT');
      console.log('Migrated: Added password column to users table.');
    }
  } catch (err) {
    console.error('Migration error:', err);
  }

  // Seed Admin if not exists
  const stmt = db.prepare('SELECT count(*) as count FROM users');
  const result = stmt.get() as { count: number };

  if (result.count === 0) {
    const insert = db.prepare('INSERT INTO users (code, name, role) VALUES (?, ?, ?)');
    insert.run('ADMIN', 'Quản trị viên', 'ADMIN');
    insert.run('NV001', 'Nguyễn Văn A', 'USER');
    console.log('Seeded default users.');
  }
};

initDb();

export default db;
