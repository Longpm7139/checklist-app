
import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
    try {
        const stmt = db.prepare('SELECT id, code, name, role FROM users ORDER BY name ASC');
        const users = stmt.all();
        return NextResponse.json({ users });
    } catch (error) {
        console.error('Get users error:', error);
        return NextResponse.json({ error: 'Lỗi server' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const { code, name, role } = await request.json();

        if (!code || !name) {
            return NextResponse.json({ error: 'Mã nhân viên và tên không được để trống' }, { status: 400 });
        }

        const stmt = db.prepare('INSERT INTO users (code, name, role) VALUES (?, ?, ?)');
        stmt.run(code, name, role || 'USER');

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Add user error:', error);
        if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
            return NextResponse.json({ error: 'Mã nhân viên đã tồn tại' }, { status: 409 });
        }
        return NextResponse.json({ error: 'Lỗi server' }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const { id } = await request.json();

        if (!id) {
            return NextResponse.json({ error: 'Thiếu ID người dùng' }, { status: 400 });
        }

        // Prevent deleting the main ADMIN
        const userStmt = db.prepare('SELECT code FROM users WHERE id = ?');
        const user = userStmt.get(id) as any;

        if (user && user.code === 'ADMIN') {
            return NextResponse.json({ error: 'Không thể xóa tài khoản Quản trị viên mặc định' }, { status: 403 });
        }

        const stmt = db.prepare('DELETE FROM users WHERE id = ?');
        stmt.run(id);

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Delete user error:', error);
        return NextResponse.json({ error: 'Lỗi server' }, { status: 500 });
    }
}
