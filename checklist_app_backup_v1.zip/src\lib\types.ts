export type Status = 'OK' | 'NOK' | 'NA';

export interface SystemCategory {
  id: string;
  name: string;
}

export interface SystemCheck {
  id: string; // e.g., 'A1'
  categoryId: string; // New field to group by category
  name: string; // e.g., 'Cầu số 1'
  status: Status | null;
  note: string;
  fixStatus?: 'Fixed' | 'Fixing' | 'No Fix';
  actionNote?: string;
  timestamp?: string;
}

export interface ChecklistItem {
  id: string;
  content: string; // Nội dung kiểm tra
  status: Status | null;
  note: string;
  timestamp?: string;
  fixStatus?: 'Fixed' | 'Fixing' | 'No Fix';
  actionNote?: string;
}

export interface ErrorReport {
  id: string;
  systemName: string;
  status: 'Fixed' | 'Fixing' | 'No Fix';
  executionContent: string;
  timestamp: string;
}
