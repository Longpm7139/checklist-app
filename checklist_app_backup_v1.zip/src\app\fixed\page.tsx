'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle, Download } from 'lucide-react';

interface HistoryItem {
    id: string;
    systemName: string;
    issueContent: string;
    timestamp: string;
    resolvedAt: string;
    actionNote: string;
}

export default function FixedPage() {
    const router = useRouter();
    const [history, setHistory] = useState<HistoryItem[]>([]);

    useEffect(() => {
        const saved = localStorage.getItem('checklist_fixed_history');
        if (saved) setHistory(JSON.parse(saved).reverse());
    }, []);

    const handleExport = () => {
        const header = ["STT", "Hệ thống", "Lỗi", "Thời gian lỗi", "Thời gian sửa", "Nội dung sửa"];
        const rows = history.map((h, index) => [
            `"${index + 1}"`,
            `"${h.systemName}"`,
            `"${h.issueContent}"`,
            `"${h.timestamp}"`,
            `"${h.resolvedAt}"`,
            `"${h.actionNote}"`
        ]);
        const csv = "\uFEFF" + [header.join(','), ...rows.map(r => r.join(','))].join('\n');
        const link = document.createElement('a');
        link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
        link.download = `history_${Date.now()}.csv`;
        link.click();
    };

    return (
        <div className="min-h-screen bg-slate-50 p-4 md:p-8 text-slate-900">
            <div className="max-w-5xl mx-auto">
                <header className="flex justify-between items-center mb-6">
                    <div className="flex items-center gap-4">
                        <button onClick={() => router.push('/')} className="p-2 bg-white rounded-full border border-slate-200 hover:bg-slate-100">
                            <ArrowLeft size={20} className="text-slate-600" />
                        </button>
                        <h1 className="text-2xl font-bold">Lịch Sử Sửa Chữa</h1>
                    </div>
                    <button onClick={handleExport} className="px-4 py-2 bg-green-600 text-white rounded-lg font-bold text-sm flex gap-2 items-center hover:bg-green-700 shadow-sm">
                        <Download size={16} /> Xuất Excel
                    </button>
                </header>

                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-700">
                                <tr>
                                    <th className="p-4">Hệ thống</th>
                                    <th className="p-4">Lỗi</th>
                                    <th className="p-4">Thời gian</th>
                                    <th className="p-4">Khắc phục</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {history.map((item, idx) => (
                                    <tr key={idx} className="hover:bg-slate-50">
                                        <td className="p-4 font-medium">{item.systemName}</td>
                                        <td className="p-4 text-red-600">{item.issueContent}</td>
                                        <td className="p-4 text-slate-500">
                                            <div>Err: {item.timestamp}</div>
                                            <div className="text-green-600">Fix: {item.resolvedAt}</div>
                                        </td>
                                        <td className="p-4 text-slate-700">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle size={16} className="text-green-500" />
                                                {item.actionNote}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
