'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { SystemCheck, Status, SystemCategory } from '@/lib/types';
import { Save, AlertCircle, Edit2, Trash2, Plus, Check, X, RotateCcw, History as HistoryIcon } from 'lucide-react';
import clsx from 'clsx';

const DEFAULT_CATEGORIES: SystemCategory[] = [
  { id: 'CAT1', name: 'A. Hệ thống Cầu hành khách' },
  { id: 'CAT2', name: 'B. Hệ thống Dẫn đỗ tàu bay' },
  { id: 'CAT3', name: 'C. Hệ thống Máy soi' },
  { id: 'CAT4', name: 'D. Hệ thống Cổng từ' },
  { id: 'CAT5', name: 'E. Hệ thống TDS' },
  { id: 'CAT6', name: 'F. Hệ thống ACS' },
  { id: 'CAT7', name: 'G. Hệ thống TEL' },
  { id: 'CAT8', name: 'H. Hệ thống CCTV' },
  { id: 'CAT9', name: 'I. Hệ thống Thu phí ETC' },
  { id: 'CAT10', name: 'J. Hệ thống thu phí xe máy' },
  { id: 'CAT11', name: 'K. Hệ thống Cửa trượt tự động' },
];

const DEFAULT_SYSTEMS: SystemCheck[] = [
  { id: 'A1', categoryId: 'CAT1', name: 'Cầu số 1', status: null, note: '' },
  { id: 'A2', categoryId: 'CAT1', name: 'Cầu số 2', status: null, note: '' },
  { id: 'A3', categoryId: 'CAT1', name: 'Cầu số 3', status: null, note: '' },
  { id: 'A4', categoryId: 'CAT1', name: 'Cầu số 4', status: null, note: '' },
  { id: 'A5', categoryId: 'CAT1', name: 'Cầu số 5', status: null, note: '' },

  { id: 'B1', categoryId: 'CAT2', name: 'Dẫn đỗ D1', status: null, note: '' },
  { id: 'B2', categoryId: 'CAT2', name: 'Dẫn đỗ D2', status: null, note: '' },

  { id: 'C1', categoryId: 'CAT3', name: 'Máy soi 1', status: null, note: '' },
  { id: 'C2', categoryId: 'CAT3', name: 'Máy soi 2', status: null, note: '' },

  { id: 'D1', categoryId: 'CAT4', name: 'Cổng từ 1', status: null, note: '' },
  { id: 'D2', categoryId: 'CAT4', name: 'Cổng từ 2', status: null, note: '' },

  { id: 'E1', categoryId: 'CAT5', name: 'TDS 1', status: null, note: '' },
  { id: 'E2', categoryId: 'CAT5', name: 'TDS 2', status: null, note: '' },

  { id: 'F1', categoryId: 'CAT6', name: 'ACS 1', status: null, note: '' },
  { id: 'F2', categoryId: 'CAT6', name: 'ACS 2', status: null, note: '' },

  { id: 'G1', categoryId: 'CAT7', name: 'TEL 1', status: null, note: '' },
  { id: 'G2', categoryId: 'CAT7', name: 'TEL 2', status: null, note: '' },

  { id: 'H1', categoryId: 'CAT8', name: 'CCTV 1', status: null, note: '' },
  { id: 'H2', categoryId: 'CAT8', name: 'CCTV 2', status: null, note: '' },

  { id: 'I1', categoryId: 'CAT9', name: 'ETC 1', status: null, note: '' },
  { id: 'I2', categoryId: 'CAT9', name: 'ETC 2', status: null, note: '' },

  { id: 'J1', categoryId: 'CAT10', name: 'Thu phí XM 1', status: null, note: '' },
  { id: 'J2', categoryId: 'CAT10', name: 'Thu phí XM 2', status: null, note: '' },

  { id: 'K1', categoryId: 'CAT11', name: 'Cửa trượt 1', status: null, note: '' },
  { id: 'K2', categoryId: 'CAT11', name: 'Cửa trượt 2', status: null, note: '' },
];

export default function Home() {
  const router = useRouter();
  const [categories, setCategories] = useState<SystemCategory[]>([]);
  const [systems, setSystems] = useState<SystemCheck[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [errors, setErrors] = useState<Set<string>>(new Set());
  const [isEditMode, setIsEditMode] = useState(false);

  useEffect(() => {
    // Load from localStorage first, then fallback to defaults
    const savedSystems = localStorage.getItem('checklist_systems');
    const savedCategories = localStorage.getItem('checklist_categories');

    if (savedCategories) {
      setCategories(JSON.parse(savedCategories));
    } else {
      setCategories(DEFAULT_CATEGORIES);
    }

    if (savedSystems) {
      setSystems(JSON.parse(savedSystems));
    } else {
      setSystems(DEFAULT_SYSTEMS);
    }

    setIsLoaded(true);
  }, []);

  // Save changes to persistence whenever systems change (for CRUD)
  // We can't rely solely on this for large apps, but for this scale it's fine.
  // However, careful not to overwrite status if we just loaded.
  // Ideally we save when we modify.

  const saveToStorage = (newSystems: SystemCheck[], newCategories?: SystemCategory[]) => {
    localStorage.setItem('checklist_systems', JSON.stringify(newSystems));
    if (newCategories) {
      localStorage.setItem('checklist_categories', JSON.stringify(newCategories));
    }
  };

  const handleStatusChange = (id: string, status: Status) => {
    const now = new Date().toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });
    const newSystems = systems.map(s => s.id === id ? { ...s, status, timestamp: now } : s);
    setSystems(newSystems);
    saveToStorage(newSystems);

    // Clear error if status is OK (as Note is not required/allowed)
    if (status === 'OK') {
      setErrors(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  const handleNoteChange = (id: string, note: string) => {
    const now = new Date().toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });
    const newSystems = systems.map(s => s.id === id ? { ...s, note, timestamp: now } : s);
    setSystems(newSystems);
    saveToStorage(newSystems);
    if (note.trim()) {
      setErrors(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  // CRUD Handlers
  const handleAddSystem = (categoryId: string) => {
    const newId = `${categoryId}_${Date.now()}`;
    const newSystem: SystemCheck = {
      id: newId,
      categoryId: categoryId,
      name: 'Hệ thống mới',
      status: null,
      note: ''
    };
    const newSystems = [...systems, newSystem];
    setSystems(newSystems);
    saveToStorage(newSystems);
  };

  const handleDeleteSystem = (id: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa hệ thống này không?')) {
      const newSystems = systems.filter(s => s.id !== id);
      setSystems(newSystems);
      saveToStorage(newSystems);
    }
  };

  const handleUpdateSystemName = (id: string, newName: string) => {
    const newSystems = systems.map(s => s.id === id ? { ...s, name: newName } : s);
    setSystems(newSystems);
    saveToStorage(newSystems);
  };

  const handleResetDefaults = () => {
    if (confirm('Bạn có chắc chắn muốn khôi phục danh sách mặc định? Mọi thay đổi sẽ bị mất.')) {
      setSystems(DEFAULT_SYSTEMS);
      setCategories(DEFAULT_CATEGORIES);
      saveToStorage(DEFAULT_SYSTEMS, DEFAULT_CATEGORIES);
    }
  };

  const handleSaveChecklist = () => {
    // 1. Validate NOK and NA notes
    const newErrors = new Set<string>();
    // Filter for both NOK and NA
    const itemsRequiringNote = systems.filter(s => s.status === 'NOK' || s.status === 'NA');

    itemsRequiringNote.forEach(s => {
      if (!s.note.trim()) {
        newErrors.add(s.id);
      }
    });

    if (newErrors.size > 0) {
      setErrors(newErrors);
      alert('Vui lòng nhập ghi chú cho các mục NOK hoặc NA!');
      return;
    }

    // 2. Save (Data is already saved on change, but we ensure it's there)
    saveToStorage(systems, categories);

    // 3. Redirect logic: Link to first NOK
    const nokItems = systems.filter(s => s.status === 'NOK');
    if (nokItems.length > 0) {
      // Go to the first NOK system found
      router.push(`/check/${nokItems[0].id}`);
    } else {
      // All OK -> Summary
      router.push('/summary');
    }
  };

  if (!isLoaded) return null;

  return (
    <div className="min-h-screen bg-slate-50 p-4 font-sans text-slate-900">
      <div className="max-w-4xl mx-auto bg-white border border-slate-300 shadow-sm relative">
        <h1 className="text-xl font-bold bg-slate-800 text-white p-4 text-center uppercase flex justify-between items-center">
          <span>Bảng Kiểm Tra Hệ Thống</span>
          <div className="flex gap-2">
            <button
              onClick={() => router.push('/fixed')}
              className="p-2 rounded text-sm font-normal flex items-center gap-1 bg-slate-700 hover:bg-slate-600 text-slate-200 transition"
              title="Xem lịch sử sửa chữa"
            >
              <HistoryIcon size={16} /> Lịch sử
            </button>
            <button
              onClick={() => setIsEditMode(!isEditMode)}
              className={clsx(
                "p-2 rounded text-sm font-normal flex items-center gap-1 transition",
                isEditMode ? "bg-yellow-500 hover:bg-yellow-600 text-slate-900" : "bg-slate-700 hover:bg-slate-600 text-slate-200"
              )}
              title={isEditMode ? "Tắt chế độ chỉnh sửa" : "Bật chế độ chỉnh sửa"}
            >
              {isEditMode ? <Check size={16} /> : <Edit2 size={16} />}
              {isEditMode ? "Xong" : "Sửa"}
            </button>
            {isEditMode && (
              <button
                onClick={handleResetDefaults}
                className="p-2 rounded text-sm font-normal flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white transition"
                title="Khôi phục mặc định"
              >
                <RotateCcw size={16} />
              </button>
            )}
          </div>
        </h1>

        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-200 text-slate-700 font-bold uppercase text-sm">
            <tr>
              <th className="p-3 border border-slate-300 w-1/3">Hệ thống</th>
              <th className="p-3 border border-slate-300 text-center w-1/3">Status</th>
              <th className="p-3 border border-slate-300 w-1/3">Note</th>
            </tr>
          </thead>
          <tbody>
            {categories.map(cat => {
              const catSystems = systems.filter(s => s.categoryId === cat.id);
              return (
                <>
                  {/* Category Header Row */}
                  <tr key={cat.id} className="bg-blue-50">
                    <td colSpan={3} className="p-3 border border-slate-300 font-bold text-blue-800">
                      {cat.name}
                    </td>
                  </tr>
                  {/* System Rows */}
                  {catSystems.map(sys => (
                    <tr key={sys.id} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-300 font-medium pl-8">
                        {isEditMode ? (
                          <div className="flex items-center gap-2">
                            <input
                              value={sys.name}
                              onChange={(e) => handleUpdateSystemName(sys.id, e.target.value)}
                              className="border border-slate-300 rounded px-2 py-1 w-full text-sm focus:border-blue-500 outline-none"
                            />
                            <button
                              onClick={() => handleDeleteSystem(sys.id)}
                              className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50"
                              title="Xóa hệ thống"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        ) : (
                          <span>{sys.name} <span className="text-xs text-slate-400 font-normal">({sys.id})</span></span>
                        )}
                      </td>
                      <td className="p-3 border border-slate-300 text-center">
                        <div className={clsx("flex gap-1 justify-center", isEditMode && "opacity-50 pointer-events-none")}>
                          {(['OK', 'NOK', 'NA'] as Status[]).map(st => (
                            <button
                              key={st}
                              onClick={() => handleStatusChange(sys.id, st)}
                              className={clsx(
                                "px-3 py-1 rounded font-bold text-xs border transition w-12",
                                sys.status === st
                                  ? (st === 'OK' ? "bg-green-600 text-white border-green-700" :
                                    st === 'NOK' ? "bg-red-600 text-white border-red-700" :
                                      "bg-slate-600 text-white border-slate-700")
                                  : "bg-white text-slate-500 border-slate-300 hover:bg-slate-100"
                              )}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </td>
                      <td className="p-3 border border-slate-300">
                        <input
                          disabled={isEditMode || sys.status === 'OK'}
                          className={clsx(
                            "w-full p-2 border rounded text-sm outline-none",
                            errors.has(sys.id) ? "border-red-500 bg-red-50 placeholder-red-300" : "border-slate-200 focus:border-blue-500",
                            (isEditMode || sys.status === 'OK') && "bg-slate-100 text-slate-400 cursor-not-allowed"
                          )}
                          placeholder={errors.has(sys.id) ? "Bắt buộc nhập ghi chú!" : (sys.status === 'OK' ? "OK không cần ghi chú" : "Ghi chú...")}
                          value={sys.note}
                          onChange={(e) => handleNoteChange(sys.id, e.target.value)}
                        />
                      </td>
                    </tr>
                  ))}
                  {/* Add System Button (Edit Mode Only) */}
                  {isEditMode && (
                    <tr className="bg-slate-50 border-b border-slate-300">
                      <td colSpan={3} className="p-2 text-center">
                        <button
                          onClick={() => handleAddSystem(cat.id)}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center justify-center gap-1 mx-auto py-1 px-3 border border-dashed border-blue-300 rounded hover:bg-blue-50 w-full"
                        >
                          <Plus size={14} /> Thêm hệ thống vào {cat.name}
                        </button>
                      </td>
                    </tr>
                  )}
                </>
              )
            })}
          </tbody>
        </table>

        {!isEditMode && (
          <div className="p-4 bg-slate-100 border-t border-slate-300 flex justify-end sticky bottom-0">
            <button
              onClick={handleSaveChecklist}
              className="px-6 py-3 bg-blue-700 text-white font-bold uppercase rounded shadow hover:bg-blue-800 flex items-center gap-2"
            >
              <Save size={20} /> Lưu Kiểm Tra
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
