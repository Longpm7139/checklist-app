'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle, Download, ChevronLeft, ChevronRight, Search, Trash2 } from 'lucide-react';
import clsx from 'clsx';
import { subscribeToHistory, deleteHistoryItem } from '@/lib/firebase';
import { useUser } from '@/providers/UserProvider';

interface HistoryItem {
    id: string;
    systemName: string;
    issueContent: string;
    timestamp: string;
    resolvedAt?: string;
    actionNote?: string;
    inspectorName?: string;
    resolverName?: string;
    imageUrl?: string;
}

export default function FixedPage() {
    const router = useRouter();
    const { user } = useUser();
    const [history, setHistory] = useState<HistoryItem[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [viewingImage, setViewingImage] = useState<string | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 10;

    useEffect(() => {
        const unsub = subscribeToHistory((data) => {
            setHistory(data as HistoryItem[]);
        });
        return () => unsub();
    }, []);

    const removeAccents = (str: string) => {
        return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
    };

    // Search and Pagination Logic
    const filteredHistory = history.filter(item => {
        if (!searchQuery.trim()) return true;
        const q = removeAccents(searchQuery.toLowerCase());
        return (
            removeAccents((item.systemName ?? '').toLowerCase()).includes(q) ||
            removeAccents((item.issueContent ?? '').toLowerCase()).includes(q) ||
            removeAccents((item.actionNote ?? '').toLowerCase()).includes(q)
        );
    });

    // Reset page when search changes
    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery]);

    const indexOfLastItem = currentPage * ITEMS_PER_PAGE;
    const indexOfFirstItem = indexOfLastItem - ITEMS_PER_PAGE;
    const currentItems = filteredHistory.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(filteredHistory.length / ITEMS_PER_PAGE);

    const handleNextPage = () => {
        if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
    };

    const highlightText = (text: string | undefined, query: string) => {
        if (!text) return text;
        if (!query.trim()) return text;

        const normalizedText = removeAccents(text.toLowerCase());
        const normalizedQuery = removeAccents(query.toLowerCase());

        if (!normalizedText.includes(normalizedQuery)) return <span>{text}</span>;

        const parts = [];
        let currentIndex = 0;
        let matchIndex = normalizedText.indexOf(normalizedQuery, currentIndex);

        while (matchIndex !== -1) {
            if (matchIndex > currentIndex) {
                parts.push(<span key={`text-${currentIndex}`}>{text.slice(currentIndex, matchIndex)}</span>);
            }
            parts.push(
                <mark key={`mark-${matchIndex}`} className="bg-yellow-300 text-slate-900 rounded px-1 font-bold">
                    {text.slice(matchIndex, matchIndex + query.length)}
                </mark>
            );
            currentIndex = matchIndex + query.length;
            matchIndex = normalizedText.indexOf(normalizedQuery, currentIndex);
        }

        if (currentIndex < text.length) {
            parts.push(<span key={`text-${currentIndex}`}>{text.slice(currentIndex)}</span>);
        }

        return <span>{parts}</span>;
    };

    const handlePrevPage = () => {
        if (currentPage > 1) setCurrentPage(prev => prev - 1);
    };

    const handleExport = () => {
        const header = ["STT", "Hệ thống", "Lỗi", "Thời gian lỗi", "Thời gian sửa", "Nội dung sửa", "Người phát hiện", "Người sửa chữa"];
        const rows = history.map((h, index) => [
            `"${index + 1}"`,
            `"${h.systemName}"`,
            `"${h.issueContent}"`,
            `"${h.timestamp}"`,
            `"${h.resolvedAt}"`,
            `"${h.actionNote}"`,
            `"${h.inspectorName || ''}"`,
            `"${h.resolverName || ''}"`
        ]);
        const csv = "\uFEFF" + [header.join(','), ...rows.map(r => r.join(','))].join('\n');
        const link = document.createElement('a');
        link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
        link.download = `history_${Date.now()}.csv`;
        link.click();
    };

    const handleDelete = async (id: string) => {
        if (confirm('Bạn có chắc chắn muốn xóa mục lịch sử này không? Hành động này không thể hoàn tác.')) {
            try {
                await deleteHistoryItem(id);
                // Data will update automatically via subscription
            } catch (error) {
                console.error("Error deleting history item:", error);
                alert("Đã xảy ra lỗi khi xóa.");
            }
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 p-4 md:p-8 text-slate-900">
            <div className="max-w-5xl mx-auto">
                <header className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                    <div className="flex items-center gap-4 w-full md:w-auto">
                        <button onClick={() => router.push('/')} className="p-2 bg-white rounded-full border border-slate-200 hover:bg-slate-100">
                            <ArrowLeft size={20} className="text-slate-600" />
                        </button>
                        <h1 className="text-2xl font-bold">Lịch Sử Sửa Chữa</h1>
                    </div>

                    <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                        <div className="relative w-full md:w-64">
                            <input
                                type="text"
                                placeholder="Tìm kiếm lịch sử..."
                                className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg focus:border-blue-500 outline-none text-sm"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                            <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
                        </div>
                        <button onClick={handleExport} className="px-4 py-2 bg-green-600 text-white rounded-lg font-bold text-sm flex gap-2 items-center justify-center hover:bg-green-700 shadow-sm whitespace-nowrap">
                            <Download size={16} /> Xuất Excel
                        </button>
                    </div>
                </header>

                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-700">
                                <tr>
                                    <th className="p-4 w-16 text-center">STT</th>
                                    <th className="p-4">Hệ thống</th>
                                    <th className="p-4">Ảnh lỗi</th>
                                    <th className="p-4">Lỗi</th>
                                    <th className="p-4">Thời gian</th>
                                    <th className="p-4">Người phát hiện</th>
                                    <th className="p-4">Người sửa chữa</th>
                                    <th className="p-4">Khắc phục</th>
                                    {user?.role === 'ADMIN' && <th className="p-4 text-center">Hành động</th>}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {currentItems.map((item, idx) => (
                                    <tr key={idx} className="hover:bg-slate-50">
                                        <td className="p-4 text-center font-bold text-slate-500">
                                            {indexOfFirstItem + idx + 1}
                                        </td>
                                        <td className="p-4 font-medium">{highlightText(item.systemName, searchQuery)}</td>
                                        <td className="p-4 text-center">
                                            {item.imageUrl && (
                                                <img 
                                                    src={item.imageUrl} 
                                                    alt="Bug" 
                                                    className="w-10 h-10 object-cover rounded shadow-sm border border-slate-200 hover:scale-110 transition cursor-pointer mx-auto"
                                                    onClick={() => setViewingImage(item.imageUrl || null)}
                                                />
                                            )}
                                        </td>
                                        <td className="p-4 text-red-600">{highlightText(item.issueContent, searchQuery)}</td>
                                        <td className="p-4 text-slate-500">
                                            <div>Err: {item.timestamp}</div>
                                            {item.resolvedAt ? (
                                                <div className="text-green-600">Fix: {item.resolvedAt}</div>
                                            ) : (
                                                <div className="text-amber-500 italic">Chờ xử lý...</div>
                                            )}
                                        </td>
                                        <td className="p-4 text-slate-600 font-medium text-sm">
                                            {item.inspectorName || '-'}
                                        </td>
                                        <td className="p-4 text-blue-600 font-bold text-sm">
                                            {item.resolverName || '-'}
                                        </td>
                                        <td className="p-4 text-slate-700">
                                            {item.actionNote ? (
                                                <div className="flex items-center gap-2">
                                                    <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                                                    <span>{highlightText(item.actionNote, searchQuery)}</span>
                                                </div>
                                            ) : (
                                                <span className="text-slate-400 italic">Chưa khắc phục</span>
                                            )}
                                        </td>
                                        {user?.role === 'ADMIN' && (
                                            <td className="p-4 text-center">
                                                <button
                                                    onClick={() => handleDelete(item.id)}
                                                    className="p-2 text-red-500 hover:bg-red-50 rounded transition"
                                                    title="Xóa mục lịch sử"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </td>
                                        )}
                                    </tr>
                                ))}
                                {currentItems.length === 0 && (
                                    <tr>
                                        <td colSpan={7} className="p-8 text-center text-slate-500 italic">
                                            {searchQuery ? 'Không tìm thấy kết quả nào phù hợp.' : 'Chưa có lịch sử sửa chữa nào.'}
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {totalPages > 1 && (
                    <div className="flex justify-center items-center gap-4 mt-6">
                        <button
                            onClick={handlePrevPage}
                            disabled={currentPage === 1}
                            className={clsx(
                                "p-2 rounded-full border transition",
                                currentPage === 1
                                    ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                                    : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50 shadow-sm"
                            )}
                        >
                            <ChevronLeft size={20} />
                        </button>
                        <span className="text-slate-600 font-medium">
                            Trang {currentPage} / {totalPages}
                        </span>
                        <button
                            onClick={handleNextPage}
                            disabled={currentPage === totalPages}
                            className={clsx(
                                "p-2 rounded-full border transition",
                                currentPage === totalPages
                                    ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                                    : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50 shadow-sm"
                            )}
                        >
                            <ChevronRight size={20} />
                        </button>
                    </div>
                )}
            </div>

            {/* Image Modal */}
            {viewingImage && (
                <div 
                    className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
                    onClick={() => setViewingImage(null)}
                >
                    <div className="relative max-w-4xl max-h-full">
                        <button 
                            className="absolute -top-12 right-0 text-white hover:text-slate-300 flex items-center gap-2 font-bold"
                            onClick={() => setViewingImage(null)}
                        >
                            <span className="text-sm">ĐÓNG</span> <span className="text-2xl">&times;</span>
                        </button>
                        <img 
                            src={viewingImage} 
                            alt="Full view" 
                            className="max-w-full max-h-[85vh] object-contain rounded shadow-2xl"
                        />
                    </div>
                </div>
            )}
        </div >
    );
}
